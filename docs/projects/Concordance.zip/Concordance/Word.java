import java.util.*;


/** This is the Word class.  It stores the text of words and where they occur in the file. 
    Each occurence of a word should be added in order since you can only access these numbers
    in a linear manner using an index*/
public class Word implements Comparable, Updatable 
//class to hold a word
{
    private String theWord;
    private Vector location, sentence;		//remembers where it occurs and in what sentences

    public Word(String w, int l, int i) 
	//constructs a word by first instance
	{
		theWord = w;						//constructs a word by name
		location = new Vector();			//and first location
		sentence = new Vector();			//and first sentence
		location.addElement(new Integer(l));
		sentence.addElement(new Integer(i));
    }

    public Word(String w, int l[], int i[])
	//constructs a word with a whole history
	{
		theWord = w;
		location = new Vector();
		sentence = new Vector();
		for(int j = 0; (j < l.length) && (j < i.length); j++) 
		{
			location.addElement(new Integer(l[j]));
			sentence.addElement(new Integer(i[j]));
		}
    }

    /**@param l the number of the word in the file
       @param i the number of the sentence in the file */
    public void addRepeat(int l, int i) 
	//called if the word is found again, remembers where
	{
		location.addElement(new Integer(l));
		sentence.addElement(new Integer(i));
    }

    /**@return the number of this word at location i */
    public int getRepeat(int i) 
	//get a certain location of the word
	{
		return ((Integer)location.elementAt(i)).intValue();
    }

    /**@return the number of the sentence this word is located at (word i)*/
    public int getSentenceIndex(int i) 
	//get a certain sentence where the word appears
	{
		return ((Integer)sentence.elementAt(i)).intValue();
    }

    /** @return number of occurences of this word */
    public int getNumRepeats()
	//number of times the word is found
	{
		return location.size();
    }

    public String getText()
	//name of the word
	{
		return theWord;
    }

    public boolean lessThan(Comparable e, int method)
	//allows a word to be compared to another word
	{
		if(method == 0) 
		{
			return theWord.compareTo(((Word)e).getText()) < 0;
		} 
		else 
		{
			int result = getNumRepeats() - ((Word)e).getNumRepeats();
			return result < 0 ? 
				true:
				(theWord.compareTo(((Word)e).getText()) < 0) && (result == 0);
		}
    }

    public int compareTo(Comparable e, int method) 
	//allows a word to be compared to another on basis of name
	{
		if(method == 0) 
		{
			return theWord.compareTo(((Word)e).getText());
		} 
		else 
		{
			int result = getNumRepeats() - ((Word)e).getNumRepeats();
			return result == 0 ?
				theWord.compareTo(((Word)e).getText()):
				result;
		}
    }

    public void update(Comparable e, int method)
	//count a repeat word
	{
		addRepeat(((Word)e).getRepeat(0),((Word)e).getSentenceIndex(0));
    }
}
