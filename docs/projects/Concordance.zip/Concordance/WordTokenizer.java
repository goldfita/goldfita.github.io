import java.util.*;


/** Break up a String into words.  A word is defined as anything seperatd by the characters in
    PUNC. */
public class WordTokenizer extends StringTokenizer //chops a string into words{
    final static String PUNC = "./<>?;:\"{}|[]\\+_=~`!@#$%^&*() \t";

    public WordTokenizer(String str)
	//removes punctuation	{
		super(replaceSpecial(str),PUNC,false);
    }

    private static String replaceSpecial(String s)
	//divides string into string of words	{
		s = " " + s + " ";
		for(int i = 1; i < s.length()-1; i++)
	    if((s.charAt(i)=='\'') || (s.charAt(i)==',')) 		{
			if(!Character.isLetterOrDigit(s.charAt(i-1))  || !Character.isLetterOrDigit(s.charAt(i+1)))
			    s = s.substring(0,i)+" "+s.substring(i+1,s.length());
	    } 		else 			if(s.charAt(i)=='-')
				if(!Character.isLetterOrDigit(s.charAt(i-1)))
					s = s.substring(0,i)+" "+s.substring(i+1,s.length());
		return s;
    }
}
