import java.util.*;
import java.lang.Math;

public class NumTree
    //This data structure holds the concordance by number of node
    //occurances
{
    private boolean empty;          //whether concordance is empty
    private TreeNode root;          //starting node
    private TreeNode overroot,overoverroot;		//two nodes positioned higher than the starting node
    private boolean isnew;          //used with insert, tells whether a node is new or a repetition
    private boolean isleft;         //used with insert, tells whether a new node should be added to the left or right
    private TreeNode current, parent, grand, great;		//temporary nodes for manipulation
    private int maxnumrepeats;
    private static Math m;
		        
    public NumTree(int totalwords)	//Tree contructor
    {
	empty=true;				//Tree starts empty
	maxnumrepeats=totalwords;
    }
        
    public void add(Word w)
    //This routine inserts a new word into the Red-Black tree
    //This word is inserted based on its numerical order
    {
	TreeNode newnode;
				
	if (empty)
				//if the tree is empty, set up the root node and hierarchy
	    {
		root=new TreeNode(w);						//if the concordance is empty, let the first word be the root
		overroot=new TreeNode(new Word("",0,0));		//make the parent of the root node null
		overoverroot=new TreeNode(new Word("",0,0));	//likewise its parent
		overroot.right=root;						//set the hierarchy up
		root.parent=overroot;						//overoverroot is the highest node
		overoverroot.right=overroot;				//overroot is its right child, and root is overroot's right child
		overroot.parent=overoverroot;
		empty=false;								//and it is no longer empty
		root.isred=false;							//root node is black
		overroot.isred=false;						//so are its parents
		overoverroot.isred=false;
	    }
	else
	    {
		newnode=findword(w);						//first check if the node already exists
		if (newnode==null)							//if not...
		    {
                                //need to create a new node
			current=root;						//start with the root
			parent=overroot;					//and set up its parents with root's parents
			grand=overoverroot;
			newnode=new TreeNode(w);			//make a node for the word
			while(current!=null)                            //run until we find a null place to put our new node
			    {
				great=grand;				//shuffle the nodes
				grand=parent;
				parent=current;
				if (index(w).compareToIgnoreCase(index(current.element))<0)		//follow the path based on the new node's alphabetical order
				    current=current.left;
				else
				    current=current.right;
				if ((current!=null)&&(current.left!=null)&&(current.right!=null))
				    if ((current.left.isred)&&(current.right.isred))        //if two red children, swap colors
					swapcolors(newnode.element);					//swap colors and rearrange
			    }
			if (index(w).compareToIgnoreCase(index(parent.element))<0)		//if it's less, put it on the left
			    {
				parent.left=newnode;				//establish the new node
				newnode.parent=parent;
				current=newnode;
			    }
			else										//otherwise the right
			    {
				parent.right=newnode;
				newnode.parent=parent;
				current=newnode;
			    }
			swapcolors(newnode.element);				//and rearrange if necessary
			root=overroot.right;						//make sure the root node is stable after rearrange
		    }
		else
		    newnode.element=w;			//if the word is already there, replace it with the new word
	    }
                
    }
		
    private void swapcolors(Word w)
    //called when two red children, swaps colors and does rotations
    {
	current.isred=true;                     //set current to red
	if (current.left!=null)
	    current.left.isred=false;       //and left child to black
	if (current.right!=null)
	    current.right.isred=false;      //and right child to black
                
	if (parent.isred)                       //if parent is red, rotate
	    {
		grand.isred=true;               //grandparent is red
		if (index(w).compareToIgnoreCase(index(grand.element))*index(w).compareToIgnoreCase(index(parent.element))<0)
		    parent=rotate(w,grand);
		current=rotate(w,great);
		current.isred=false;                            //current color is black
	    }
	root.isred=false;                       //let root be black;
	overroot.isred=false;
	overoverroot.isred=false;
    }
        
    private TreeNode rotate(Word w, TreeNode parent)
    //performs a single rotation
    {
	if (index(w).compareToIgnoreCase(index(parent.element))<0)
	    {
		if (index(w).compareToIgnoreCase(index(parent.left.element))<0)
		    parent.left=withLeftChild(parent.left);
		else
		    parent.left=withRightChild(parent.left);
		return(parent.left);
	    }
	else
	    {
		if (index(w).compareToIgnoreCase(index(parent.right.element))<0)
		    parent.right=withLeftChild(parent.right);
		else
		    parent.right=withRightChild(parent.right);
		return(parent.right);
	    }
    }
       
    private TreeNode withLeftChild(TreeNode k2)
    //one rotation
    {
	TreeNode k1 = k2.left;
	k2.left=k1.right;
	k1.right=k2;
	return k1;
    }
        
    private TreeNode withRightChild(TreeNode k1)
    //one rotation
    {
	TreeNode k2 = k1.right;
	k1.right=k2.left;
	k2.left=k1;
	return k2;
    }
        
    private TreeNode findword(Word w)
    //finds a node given a word
    {
	TreeNode anode;
	boolean leave=false;
                
	anode=root;                                     //start at the root
	while (!leave)
	    {
		if ((index(anode.element).compareToIgnoreCase(index(w))>0)&&(anode.left!=null))
		    anode=anode.left;       //if the word has an earlier name, go left
		else if ((index(anode.element).compareToIgnoreCase(index(w))>0)&&(anode.right!=null))
		    anode=anode.right;      //if the word has a later name, go right
		else if (index(anode.element).equalsIgnoreCase(index(w)))
		    leave=true;                     //a match is found
		else
		    {
			anode=null;				//returns null if it cannot be found                 //if there isn't a match, leave anyway
			leave=true;
		    }
	    }
	return(anode);
    }
        
    public Word find(Word w)
    //finds a word in the tree given an example of it
    {
	TreeNode wordout;
			
	wordout=findword(w);
	if (wordout!=null)
	    return(wordout.element);
	else
	    return(null);		//returns null if it cannot be found
    }
        
    public boolean isEmpty()
    //returns whether the concordance is empty
    {
	return(empty);
    }
		
    private String index(Word w)
    //constructs a unique identifier for a word
    //based first on its number of repetitions,
    //and then on its name
    {
	String alpha="";
	int expon,i,wtemp;
			
	wtemp=w.getNumRepeats();
	expon=((int)m.floor(m.log(maxnumrepeats)/m.log(10)));	//separates digits (so that 72 > 8)
	for (i=expon;i>0;i--)
	    {
		alpha+=(int)(m.floor((wtemp/(m.pow(10,i)))));
		alpha+="-";
		wtemp=wtemp-(int)((m.floor(wtemp/(m.pow(10,i))))*m.pow(10,i));
	    }
	alpha+=w.getNumRepeats();
	alpha+="-";
	alpha+=w.getText();			
	return alpha;
    }
		
    public Vector listtree()
    //returns sorted tree contents in a vector
    {
	Vector treedump;
			
	treedump=new Vector();
	listtreeloop(root,treedump);
	return treedump;
    }
		
    private void listtreeloop(TreeNode t, Vector treedump)
    //internal recursive function to list the tree
    {
	if (t!=null)
	    {
		listtreeloop(t.left, treedump);		//travel down left node
		treedump.addElement(t.element);		//add node
		listtreeloop(t.right,treedump);		//travel down right node
	    }
    }
}
