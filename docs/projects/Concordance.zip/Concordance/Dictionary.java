import java.io.*;
import java.util.*;

/** This is the dictionary class.  Put words in here that you don't want in your concorance. */
    
public class Dictionary 
//the dictionary is a list of words that are too common to be
//included in the concordance{
    private BufferedReader dictionary;
    private Tree theWords;					//a special tree for the dictionary

    public Dictionary() 	{
		theWords = new Tree();		//when the dictionary is constructed, it constructs a tree
    }

    public Dictionary(String f) throws FileNotFoundException
	//when constructed with a string, it prepares to opens the file of the name of that string	{
		dictionary = new BufferedReader(new FileReader(f));
		theWords = new Tree();		//and constructs a tree
    }

    public void readInDictionary() 
	//reads in the dictionary from a file	{
		String s;
			   
		try 		{
			while((s=dictionary.readLine()) != null)	//line by line
			theWords.add(s, 1, 1);
		}
		catch(IOException ioe) 		{ 			ioe.printStackTrace();		//if problem accessing file		}
    }

    public void add(Word w)
	//adds a word to the dictionary by adding it to the tree	{
		theWords.add(w.getText(), 1, 1);
    }

    /** @return true if w is in the dictionary */
    public boolean contains(Word w) 
	//does the dictionary have a certain word?
	//check the tree to find out!	{
		if(theWords.find(w) != null) 
			return true;				//true, it does
		return false;					//false, it does not
    }
}
