import java.util.*;

public class TreeNode
//a node for a tree, consisting of a word
{
    public Word element;				//node's word
    public TreeNode left;				//left child node
    public TreeNode right;				//right child node
    public boolean isred;				//red or black
    public TreeNode parent;				//parent node
	
    public TreeNode(Word w)
	//constructor creates a node
    {
		this.left=left;
		this.right=right;
		element=w;
		parent = null;
		isred=false;						//all new nodes are red
    }
	
    public void setleft(TreeNode l)
	//creates a left child
    {
		left=l;
    }
	
    public void setright(TreeNode r)
	//creates a right child
    {
		right=r;
    }
	
    public String name()
	//returns the name of the word in the node
    {
		return(((Word)element).getText());
    }
	
    public Word theWord() 
	//returns the word in the node
	{
		return element;
    }
}
