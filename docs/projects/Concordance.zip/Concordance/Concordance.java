import java.util.*;
import java.io.*;

/** @author Todd, Alla, Mike
    This is the main file. */
public class Concordance //This is the main function.
{
    public final static String DEFAULT_DICTIONARY = "default.dic";
    private TextInput theFile;					//source for text
    private Tree theWords;						//alphabetical tree
    private Dictionary dic, userDic;			//main dictionary and user dictionary
    private Gui g;								//graphic interface
    private Vector wordsByNumber, wordsByKeyword;	//list of words sorted by number and keyword
    private String dicName;						//name of the dictionary

    public static void main(String[] args) 
    //Execution begins here
    //The concordance is constructed and set up here
    //From this point on, execution is event driven	{
	Concordance c = new Concordance();
	c.g = new Gui(c);
	c.theWords = null;
	c.theFile = null;
	c.dic = null;
	c.userDic = null;
	c.wordsByNumber = null;
	c.dicName = Concordance.DEFAULT_DICTIONARY;		//let the first dictionary be the default
    }

    /** @param max the maximum number of characters to place in the String returned 
	@return the start of the text file */
    public String getText(int max)
    //sets up the original text to be outputed to the left window	{
	String s = "", tmp = "";

	for(int i = 0; i < theFile.numSentences(); i++)		//let this be done for each sentence		{
	    tmp = theFile.getSentence(i)+"\n";				//put a new line after each sentence
	    if(s.length() + tmp.length() > max) 			{
		s = "*** This text has been truncated ***\n\n" + s;	//too much text
		break;
	    } 			else
		s += tmp;
	}
	return s;									//return formatted text
    }

    /** specify the name of the dictionary */
    public void setDictionaryName(String name)
    //sets the current dictionary name based on the input string	{
	dicName = name;
    }

     /** 
	 @param str the word to find
	 @param max the maximum number of characters to place in the String returned 
	 @return words in the text file */
    public String getAllOccurences(String str, int max)
    //returns a string containing all of the locations a requested word exists in the input file	{
	Word w;
	String s = "", tmp = "";
	int last = -1, count = 0;

	if(userDic.contains(new Word(str, 1, 1)))		//first check if the word is marked to be ignored
	    return null;
	w = theWords.find(new Word(str, -1, -1));		//now check if the word exists in the tree
	if(w == null)
	    return null;							//if not, return null

	s = "There are " + w.getNumRepeats() + " occurences of '" + str + "'."; //output word and number of occurances
	for(int i = 0; i < w.getNumRepeats(); i++) 		{
	    if(last != w.getSentenceIndex(i)) 			{				//show all of the places the word is found
		tmp = "\n\n" + (++count) + ") " + theFile.getSentence(last=w.getSentenceIndex(i)) + 
		    "\n\tSentence Number: " + (w.getSentenceIndex(i)+1) + "\n\tWord Number(s): " + (w.getRepeat(i)+1);
	    } 			else 			{
		tmp = " " + w.getRepeat(i);
	    }
	    if(s.length() + tmp.length() > max)		//truncate if text is too long			{
		s = "*** This text has been truncated ***\n\n" + s;
		break;
	    } 			else
		s += tmp;		//otherwise return the text to be outputed
	}
	return s;
    }

    /** @param max the maximum number of characters to place in the String returned 
       @return words sorted by number */
    public String sortByNumber(int max)
    //outputs a string to be displayed containing the list of words
    //in ascending order of frequency of occurance	{
	String s = "", tmp = "";

	if (wordsByNumber == null)
	    wordsByNumber = theWords.sortByNum().listtree();	//if words haven't been sorted this way, sort them
	for(int i = wordsByNumber.size()-1; i >= 0; i--)
	    if (!userDic.contains((Word)wordsByNumber.elementAt(i)))	//ignore words in the dictionary			{				//show word and number of occurances
		tmp = ((Word)wordsByNumber.elementAt(i)).getNumRepeats() + ": " + 
		    ((Word)wordsByNumber.elementAt(i)).getText() + "\n";
		if (s.length() + tmp.length() > max) 				{					//if too long, truncate it
		    s = "*** This text has been truncated ***\n\n" + s;
		    break;
		} 				else					s += tmp;	//otherwise, output it
	    }
	return s;
    }		public String sortByKeyword(int max) 
    //outputs a string to be displayed containing the list of words
    //in alphabetical order	{
	String s = "", tmp = "";

	if (wordsByKeyword == null)
	    wordsByKeyword = theWords.inOrderCopy();		//if list of words doesn't exist, make it
	for(int i = 0; i <= wordsByKeyword.size()-1; i++)
	    if(!userDic.contains((Word)wordsByKeyword.elementAt(i))) //ignore words in dictionary			{				//format word for display
		tmp = ((Word)wordsByKeyword.elementAt(i)).getNumRepeats() + ": " + 
		    ((Word)wordsByKeyword.elementAt(i)).getText() + "\n";
		if(s.length() + tmp.length() > max) 				{					//truncate if too long
		    s = "*** This text has been truncated ***\n\n" + s;
		    break;
		} 				else
		    s += tmp;	//otherwise display it
	    }
	return s;
    }
    
    /** add words we don't want to the dictionary 
	@param n if the word appears n or more times, place it in the dictionary */
    public void addToDictionary(int n)
    //all words that appear more than n times are added
    //to the dictionary of words to ignore	{
	for(int i = wordsByNumber.size()-1; i >= 0; i--)
	    if (((Word)wordsByNumber.elementAt(i)).getNumRepeats() >= n)
		userDic.add((Word)wordsByNumber.elementAt(i));
	    else
		break;
    }

    /** generate teh file and the dictionary
	@param method the method used to parse the file
	@see TextInput*/
    public String generate(String file, int method)
    //contructs the concordance from the input file	{
	String s;
	int wc = 0;		//keeps a running count so each word's place in the file can be saved

	try 		{
	    dic = null;						//first assemble a dictionary
	    dic = new Dictionary(dicName);
	    dic.readInDictionary();			//and try to read it in
	} 		catch(FileNotFoundException fnfe) 		{ 
	    return "Can't find dictionary " + dicName + ".";	//unless it can't be found
	}
	try 		{
	    theFile = new TextInput(file, method);
	    theFile.read();					//then try to read in the text file
	} 		catch(FileNotFoundException fnfe) 		{ 
	    return "That isn't a valid input file, you fool!";	//but prepare for a file not found
	}

	userDic = new Dictionary();			//create the dictionary
	theWords = new Tree();				//create the tree to hold the words
	for (int i = 0; i < theFile.numSentences(); i++) 		{
	    WordTokenizer wt = new WordTokenizer(theFile.getSentence(i));	//break the file into words
	    while(wt.hasMoreTokens()) 			{
		if(!dic.contains(new Word(s = wt.nextToken(), 1, 1)))
		    theWords.add(s,wc++, i);	//and add each word to the tree
	    }
	}
	wordsByNumber = null;
	return null;
    }

    /** write the concordance to a file */
    public void writeConcordance(String file) throws IOException 	//writes the whole concordance construction to a file	{
	BufferedWriter theFile = new BufferedWriter(new FileWriter(file));	//create the output file
	if(theWords == null)
	    return;				//if there are no words to write, just exit
	Vector w = theWords.inOrderCopy();	//get the words in alphabetical order
	int last = -1;

	try 		{
	    for(int i = 0; i < w.size(); i++)	//repeated for every word			{
		if(!userDic.contains((Word)w.elementAt(i))) 				{
		    theFile.write(((Word)w.elementAt(i)).getText() + "\nSentences: ");	//write word
		    for(int j = 0; j < ((Word)w.elementAt(i)).getNumRepeats(); j++) 					{
			if (last != ((Word)w.elementAt(i)).getSentenceIndex(j))			//and every sentence it appears in
			    theFile.write((((Word)w.elementAt(i)).getSentenceIndex(j)+1) + " ");
			last = ((Word)w.elementAt(i)).getSentenceIndex(j);
		    }
		    theFile.write("\nWords: ");
		    for (int j = 0; j < ((Word)w.elementAt(i)).getNumRepeats(); j++)	//write all places the word appears
			theFile.write((((Word)w.elementAt(i)).getRepeat(j)+1) + " ");
		    theFile.write("\n\n");
		}
	    }
	    theFile.close();			//and close the file
	}		catch(IOException ioe) 		{ 			ioe.printStackTrace();		//what to do if there is a disk write error		}
    }
}
