import java.util.*;

/** Break up a String of sentences into sentences. 
    A sentence is defined as anything terminated by ? or . or ! and which
    is followed by a captial letter within 3 characters and cannot be preceded
    by Mr., Ms., Dr., or Mrs.*/
public class SentenceTokenizer
//divides a string into sentences{
    private String theString;
    private static String TITLE[];
    private boolean endString;

    static 	{
		TITLE = new String[4];
		TITLE[0] = " Mr.";
		TITLE[1] = " Ms.";
		TITLE[2] = " Dr.";		TITLE[3] = " Mrs. ";
    }

    public SentenceTokenizer(String str) 
	//is string null?	{
		endString = (str == null) ? true: false;
		theString = str;
    }

    public String nextToken()
	//selects next sentence	{
		for (int i = 0; i < theString.length(); i++) 		{
			if (Character.isUpperCase(theString.charAt(i)))
			//identifies beginnings by uppercase characters			{
				for (int j=i,c=2; (j>=0) && (c>=0); j--) 				{
					if (!Character.isWhitespace(theString.charAt(j)))					{
						c--;
						if(endSentence(theString.charAt(j))) 						{
							if(!isTitle(j-3)) 
							return splitTokens(j);
						}
					}
				}
			}
		}
		return splitTokens(theString.length()-1);
    }

    private boolean endSentence(char c)
	//identifies ends by periods, question marks, and exclamation marks	{
		return (c == '.' || c == '?' || c == '!');
    }
    
    private boolean isTitle(int start)
	//prevents a person's title from counting
	//as the end of a sentence	{
		if(start >= 0) {
		    if(TITLE[0].charAt(0) == theString.charAt(start)   &&
		       TITLE[0].charAt(1) == theString.charAt(start+1) &&
		       TITLE[0].charAt(2) == theString.charAt(start+2))
			return true;
		    if(TITLE[1].charAt(0) == theString.charAt(start)   &&
		       TITLE[1].charAt(1) == theString.charAt(start+1) &&
		       TITLE[1].charAt(2) == theString.charAt(start+2))
			return true;
		    if(TITLE[2].charAt(0) == theString.charAt(start)   &&
		       TITLE[2].charAt(1) == theString.charAt(start+1) &&
		       TITLE[2].charAt(2) == theString.charAt(start+2))
			return true;
		    if(TITLE[3].charAt(0) == theString.charAt(start)   &&
		       TITLE[3].charAt(1) == theString.charAt(start+1) &&
		       TITLE[3].charAt(2) == theString.charAt(start+2))
			return true;
		}
		return false;
    }
	    
    private String splitTokens(int brk)
	{
		String tmp;

		tmp = theString.substring(0, brk+1);
		if (brk+1!=theString.length())
			theString = theString.substring(brk+2, theString.length());
		else 		{
			theString = null;
			endString = true;
		}
		return tmp;
    }

    public boolean hasMoreTokens()
	//are there more sentences?	{
		return !endString;
    }
}
