import java.awt.*;
import java.awt.event.*;


/** Just a message box. */
public class GuiText extends Frame //implements the popup boxes to show messages
{
    private Button ok;						//button to enter
    private Label type;						//popup label
    private ActionListener actionListener;	//button handler

    public GuiText(ActionListener al, String msg)
	//constructor, creates the window	{
		actionListener = al;				//sets action listener
		type = new Label(msg);				//sets label for message
		ok = new Button("Okay! :-)");				//creates button
		ok.setName ("Okay! :-)");			//sets its name

		add(type, "North");					//puts message area at top
		add(ok, "South");					//and button at the bottom
		setSize(500,75);					//and makes the button big
		ok.addActionListener (al);			//and activates button
		
		setTitle ("Message Box");			//title for box
		show();								//make it visible
    }
}
