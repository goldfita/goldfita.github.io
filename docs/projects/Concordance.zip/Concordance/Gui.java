import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.util.*;

/** This is the Gui class.  It takes care of all user interface events and updating graphics.  When
    an event occurs, an action handler is called and it runs the necessary concordance code.  The interface
    to this class is very simple.  Construct a new Gui taking a pointer to the Concordance class.*/
public class Gui extends Frame
    //this class creates the main window and graphic interface
{
    public GuiTextInput currentInput;				//Text input
    public GuiText currentText;						//original file output
    public final static int MAX_STRING_LEN = 10000;	//maximum length of a text box
    private TextArea text;							//file output
    private TextArea conc;							//concordance output
    private TextArea mode;							//mode output
    private Button search;							//button to find a word
    private TextField type;							//field to enter a word
    private MenuBar mb;								//menu bar
    private Menu file, searchby, parse;				//menus
    private MenuItem New, searchMethod, dic, parseby, concFile,Exit;	//menu items
    private Frame mframe;							//window
    private Concordance theConcordance;				//concordance
    private boolean waitingIn, waitingMsg, inKeywordMode, concordanceOpen, inParseBySentenceMode, inDefaultMode;	//states
    private static Image backbmap;					//background image

    /**The concordance code is run by action handlers.  Once a new Gui is created, no other work needs to be done here.
     @see Concordance*/
    public Gui(Concordance c)
    //contructs GUI
    {
	theConcordance = c;							//creates concordance
	waitingIn = waitingMsg = false;				//first states
	concordanceOpen = false;
	inKeywordMode = true;
	inParseBySentenceMode = true;
	inDefaultMode = true;

	Color backcolor = new Color (230, 230, 250);	//background color
	Color textcolor = new Color (253, 248, 255);	//text input field color
		
	text = new TextArea();					//sets up fields and buttons
	conc = new TextArea();
	mode = new TextArea();
	type = new TextField();
	search = new Button("Search");
	search.setName ("Search");
	
	mb = new MenuBar ();					//creates menu bar
	file = new Menu ("File", true);			//File menu
	mb.add (file);
	New = new MenuItem ("New Concordance");	//adds items to it
	file.add (New);
		
	New.addActionListener(new ActionListener() //add listener to item
	    {
		public void actionPerformed(ActionEvent e) 
		{
		    selectNewConcordance("File Name");
		}
	    });
	dic = new MenuItem ("My Dictionary");	//adds menu item
	file.add(dic);
	dic.addActionListener(new ActionListener() //adds listener
	    {
		public void actionPerformed(ActionEvent e) 
		{
		    if(inDefaultMode) 
			{
			    getUserDictionary("Enter dictionary file please.");	//prompts for new dictionary
			    dic.setLabel("Default");
			} 
		    else 
			{
			    theConcordance.setDictionaryName(Concordance.DEFAULT_DICTIONARY);  //set it to be default
			    dic.setLabel("My Dictionary");
			}
		    inDefaultMode = !inDefaultMode;
		    redisplayMode();				//set new mode
		}
	    });
	concFile = new MenuItem("Write Final");		//new menu item
	file.add(concFile);
	concFile.addActionListener(new ActionListener() //add listener
	    {
		public void actionPerformed(ActionEvent e) 
		{
		    getOutFile("Enter a file to write to: ");	//ask for filename
		}
	    });
	Exit = new MenuItem ("Exit");			//adds items to it
	file.add (Exit);
		
	Exit.addActionListener(new ActionListener() //add listener to item
	    {
		public void actionPerformed(ActionEvent e) 
		{
		    System.exit(0);		//quit
		}
	    });
	searchby = new Menu("Searchby", true);		//new menu
	mb.add (searchby);
	searchby.addActionListener (new ActionListener() //add listener
	    {
		public void actionPerformed(ActionEvent e) 
		{
		    if(inKeywordMode && concordanceOpen) 
			{
			    searchMethod.setLabel("Keyword");	//if in number mode, switch to view by keyword
			    search.setLabel("Remove");
			    sortByNumber();
			    inKeywordMode = false;
			} 
		    else 
			{
			    searchMethod.setLabel("Number");	//otherwise, switch to view by number
			    search.setLabel("Search");
			    sortByKeyword();
			    inKeywordMode = true;
			}
		    redisplayMode();						//and redisplay
		}
	    });
	searchMethod = new MenuItem ("Number");		//new menuitem
	searchby.add (searchMethod);
	parse = new Menu("Parse");					//new menu
	parseby = new MenuItem("By New Line");		//new menuitem
	parse.add(parseby);
	parse.addActionListener(new ActionListener()	//add listener
	    {
		public void actionPerformed(ActionEvent e) 
		{
		    if(inParseBySentenceMode)		//if in parse by keyword mode, switch to sentence
			{
			    parseby.setLabel("By Sentence");
			} 
		    else 
			{
			    parseby.setLabel("By New Line");	//otherwise, parse by new line
			}
		    inParseBySentenceMode = !inParseBySentenceMode;
		    redisplayMode();			//and redisplay
		}
	    });
	mb.add(parse);

	mframe = this;
	mframe.setLayout (null);			//set up layout
	mframe.setMenuBar (mb);				//and menu bar
	mframe.add(text);					//add on the original file display box
	text.setBounds (40,100,300,300);	//set its location
	text.setEditable (false);
	text.setBackground (textcolor);
	mframe.add(conc);					//add on the concordance display box
	conc.setBounds (350, 100,300,300);
	conc.setEditable (false);
	conc.setBackground (textcolor);
	mframe.add (type);
	mode.setBounds(700, 100, 120, 100);
	mode.setEditable(false);
	mode.setBackground(textcolor);
	mframe.add(mode);					//add on the mode display box
	redisplayMode();
	type.setBounds (40, 420, 500, 20);
	mframe.add(search);
	search.setBounds (550, 420, 100, 20);

	mframe.addWindowListener (new myWindowListener ());	//set up listeners
	search.addActionListener (new ActionListener()	//add listener to prompt sorting
	    {
		public void actionPerformed(ActionEvent e) 
		{
		    String s;
		    if((s = type.getText()).length() > 0) 
			{
			    if(inKeywordMode) 
				{
				    conc.setText("Searching...");
				    sleep(100);
				    searchByText(s);
				} 
			    else 
				{
				    theConcordance.addToDictionary(getValue(s));
				    sortByNumber();
				}
			}
		}
	    });
		
	mframe.setTitle ("Yay, It's A Concordance!");		//window label
	mframe.resize(850,500);
	mframe.setBackground (backcolor);
	backbmap = (Toolkit.getDefaultToolkit()).getImage("bk1.jpg");		//get the image file
	backCanvas theback = new backCanvas();				//construct the canvas
	mframe.add(theback);								//add it to the window
	
	mframe.show();										//make the window visible
    }
		
    public static class myWindowListener extends WindowAdapter
	//window listener
    {
	public void windowClosing(WindowEvent evt)
	{
	    System.exit(0);		//quit
	}	
    }

    private void selectNewConcordance(String msg)
    //routine for making a new concordance
    {
	if(waitingIn == false) 
	    {
		waitingIn = true;
		currentInput = new GuiTextInput(new ActionListener() 
		    {
			public void actionPerformed(ActionEvent e) 
			{
			    currentInput.dispose();
			    String file = currentInput.getText();	//get name
			    String s, tmp;

			    tmp = text.getText();
			    text.setText("generating...");			//construct it
			    sleep(250);
			    if((s=theConcordance.generate(file, inParseBySentenceMode ? 
							  TextInput.PARSE_BY_SENTENCE: TextInput.PARSE_BY_NEWLINE)) != null)	//parse it 
				{
				    displayMessage(s);				//display it
				    getToolkit().beep();
				    text.setText(tmp);
				} 
			    else 
				{
				    concordanceOpen = true;
				    inKeywordMode = true;
				    conc.setText("");
				    text.setText("may be unable to display file");
				    search.setLabel("Search");
				    searchMethod.setLabel("Number");
				    inKeywordMode = true;
				    redisplayMode();
				    text.setText(theConcordance.getText(Gui.MAX_STRING_LEN));
				}
			    waitingIn = false;
			}
		    }, msg);
	    }
    }


    private void getUserDictionary(String msg) 
    //get the dictionary
    {
	if(waitingIn == false) 
	    {
		waitingIn = true;
		currentInput = new GuiTextInput(new ActionListener() 
		    {
			public void actionPerformed(ActionEvent e) 
			{
			    currentInput.dispose();
			    String file = currentInput.getText();	//get the file name for a new dictionary
			    theConcordance.setDictionaryName(file);   
			    waitingIn = false;
			}
		    }, msg);
	    }
    }

    private void getOutFile(String msg) 
    //get the file name for the concordance output,
    //write the concordance to the file
    {
	if(waitingIn == false) 
	    {
		waitingIn = true;
		currentInput = new GuiTextInput(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			    currentInput.dispose();
			    String file = currentInput.getText();
			    try {
				theConcordance.writeConcordance(file);  
			    } 
			    catch(IOException ioe){
				displayMessage("Not a valid file silly");
			    }
			    waitingIn = false;
			}
		    }, msg);
	    }
    }


    private void displayMessage(String msg) 
    //display a message box
    {
	if(waitingMsg == false) 
	    {
		waitingMsg = true;
		currentText = new GuiText(new ActionListener() 
		    {
			public void actionPerformed(ActionEvent e) 
			{
			    currentText.dispose();
			    waitingMsg = false;
			}
		    }, msg);
	    } 
	else 
	    {
		waitingMsg = false;
		currentText.dispose();
		displayMessage(msg);
	    }
    }

    private void searchByText(String s) 
    //find a word in the concordance
    {
	String str = theConcordance.getAllOccurences(s, Gui.MAX_STRING_LEN);
	conc.setText("may be unable to display results");
	if(str != null)
	    conc.setText(str);
	else
	    conc.setText("I tried, but I just couldn't find '" + s + "'.");
    }

    private void sortByNumber() 
    //sort the concordance output by the number of times a word
    //is found
    {
	String s;

	conc.setText("sorting by number...");
	sleep(100);
	s = theConcordance.sortByNumber(Gui.MAX_STRING_LEN);
	conc.setText("may be unable to display results");
	conc.setText(s);
    }
	
    private void sortByKeyword()
    //sort the concordance output alphabetically by word
    {
	String s;
		
	conc.setText("sorting by keyword...");
	sleep(100);
	s = theConcordance.sortByKeyword(Gui.MAX_STRING_LEN);
	conc.setText("may be unable to display results");
	conc.setText(s);		
    }

    private int getValue(String s) 
    //get a numberical value for the string
    {
	try 
	    {
		return Integer.parseInt(s);
	    } 
	catch(NumberFormatException nfe) 
	    { 
		return Integer.MAX_VALUE; 
	    }
    }

    private void redisplayMode() 
    //update mode window to show current situation,
    //also, update menu bar to show newest choices
    {
	String s = "Current Mode:\n\n";

	s += (inKeywordMode ? "keyword\n": "number\n");
	s += (inParseBySentenceMode ? "sentence\n": "new line\n");
	s += (inDefaultMode ? "default": "my dictionary");
	mode.setForeground(Color.red);
	mode.setText(s);
	searchby.add(searchMethod);
	mb.add(searchby);
	parse.add(parseby);
	mb.add(parse);
	mframe.setMenuBar (mb);
    }

    private void sleep(int milli) 
    //allows pauses in execution
    {
	try 
	    { 
		Thread.sleep(milli);
	    }
	catch(InterruptedException ie) 
	    { 
	    }
    }
	
    public static class backCanvas extends Canvas
	//Canvas to manage the background bitmap
    {
	public backCanvas()
	{
	    setSize(850,500);					//size of the bitmap
	}
	public void paint(Graphics g)
	{
	    g.drawImage(backbmap, 0, 40, this);	//draw the bitmap across the canvas
	}
    }
}
