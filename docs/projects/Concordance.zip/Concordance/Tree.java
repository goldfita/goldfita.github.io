import java.util.*;

public class Tree
    //This is the data structure that holds the concordance
{
    private boolean empty;          //whether concordance is empty
    private TreeNode root;          //starting node
    private TreeNode overroot,overoverroot;		//two nodes positioned higher than the starting node
    private boolean isnew;          //used with insert, tells whether a node is new or a repetition
    private boolean isleft;         //used with insert, tells whether a new node should be added to the left or right
    private TreeNode current, parent, grand, great;		//temporary nodes for manipulation
    private int size;
        
    public Tree()                   //Tree contructor
    {
		empty=true;				//Tree starts empty
		root=new TreeNode(new Word("\0",0,0));  //create a dummy root node
    }
        
    public void add(String wname, int loc, int sent)
    //This routine inserts a new word into the Red-Black tree
    //This word is inserted based on its alphabetical order
    {
		TreeNode newnode;
					
		if (empty)
					//if the tree is empty, set up the root node and hierarchy
		    {
			root=new TreeNode(new Word(wname,loc,sent));		//if the concordance is empty, let the first word be the root
			overroot=new TreeNode(new Word("",0,0));		//make the parent of the root node null
			overoverroot=new TreeNode(new Word("",0,0));	//likewise its parent
			overroot.right=root;						//set the hierarchy up
			root.parent=overroot;						//overoverroot is the highest node
			overoverroot.right=overroot;				//overroot is its right child, and root is overroot's right child
			overroot.parent=overoverroot;
			empty=false;								//and it is no longer empty
			root.isred=false;							//root node is black
			overroot.isred=false;						//so are its parents
			overoverroot.isred=false;
			size=1;
		    }
		else
		    {
			newnode=findword(wname);						//first check if the node already exists
			if (newnode==null)							//if not...
			    {
		                            //need to create a new node
				size++;
				current=root;						//start with the root
				parent=overroot;					//and set up its parents with root's parents
				grand=overoverroot;
				newnode=new TreeNode(new Word(wname,loc,sent));		//make a node for the word
				while(current!=null)                            //run until we find a null place to put our new node
				    {
					great=grand;				//shuffle the nodes
					grand=parent;
					parent=current;
					if (wname.compareToIgnoreCase(current.name())<0)	//follow the path based on the new node's alphabetical order
					    current=current.left;
					else
					    current=current.right;
					if ((current!=null)&&(current.left!=null)&&(current.right!=null))
					    if ((current.left.isred)&&(current.right.isred))        //if two red children, swap colors
						swapcolors(newnode.element);					//swap colors and rearrange
				    }
				if (wname.compareToIgnoreCase(parent.name())<0)		//if it's less, put it on the left
				    {
					parent.left=newnode;				//establish the new node
					newnode.parent=parent;
					current=newnode;
				    }
				else										//otherwise the right
				    {
					parent.right=newnode;
					newnode.parent=parent;
					current=newnode;
				    }
				swapcolors(newnode.element);				//and rearrange if necessary
				root=overroot.right;						//make sure the root node is stable after rearrange
			    }
			else
			    {
				newnode.element.addRepeat(loc,sent);			//if node already exists, add the new location
			    }
		    }		            
    }
		
    private void swapcolors(Word w)
    //called when two red children, swaps colors and does rotations
    {
		current.isred=true;                     //set current to red
		if (current.left!=null)
		    current.left.isred=false;       //and left child to black
		if (current.right!=null)
		    current.right.isred=false;      //and right child to black
		            
		if (parent.isred)                       //if parent is red, rotate
		    {
			grand.isred=true;               //grandparent is red
			if (w.getText().compareToIgnoreCase(grand.name())*w.getText().compareToIgnoreCase(parent.name())<0)
			    parent=rotate(w,grand);
			current=rotate(w,great);
			current.isred=false;                            //current color is black
		    }
		root.isred=false;                       //let root be black;
		overroot.isred=false;
		overoverroot.isred=false;
    }
        
    private TreeNode rotate(Word w, TreeNode parent)
    //performs a single rotation
    {
		if (w.getText().compareToIgnoreCase(parent.name())<0)
		    {
			if (w.getText().compareToIgnoreCase(parent.left.name())<0)
			    parent.left=withLeftChild(parent.left);
			else
			    parent.left=withRightChild(parent.left);
			return(parent.left);
		    }
		else
		    {
			if (w.getText().compareToIgnoreCase(parent.right.name())<0)
			    parent.right=withLeftChild(parent.right);
			else
			    parent.right=withRightChild(parent.right);
			return(parent.right);
		    }
    }
       
    private TreeNode withLeftChild(TreeNode k2)
	//one rotation
    {
		TreeNode k1 = k2.left;
		k2.left=k1.right;
		k1.right=k2;
		return k1;
    }
        
    private TreeNode withRightChild(TreeNode k1)
	//one rotation
    {
		TreeNode k2 = k1.right;
		k1.right=k2.left;
		k2.left=k1;
		return k2;
    }
        
    private TreeNode findword(String wname)
    //finds a node given a word name
    {
		TreeNode anode;
		boolean leave=false;
		anode=root;                                     //start at the root
		while (!leave)
		    {
			if ((anode.name().compareToIgnoreCase(wname)>0)&&(anode.left!=null))
			    anode=anode.left;       //if the word has an earlier name, go left
			else if ((anode.name().compareToIgnoreCase(wname)<0)&&(anode.right!=null))
			    anode=anode.right;      //if the word has a later name, go right
			else if (anode.name().equalsIgnoreCase(wname))
			    leave=true;                     //a match is found
			else
			    {
				anode=null;                     //if there isn't a match, leave anyway
				leave=true;
			    }
		    }
		return(anode);
    }
        
    public Word find(Word w)
	//finds a word given an example of its name
    {
		TreeNode wordout;
		String wname;
	
	
		wname=w.getText();
		wordout=findword(wname);
		if (wordout!=null)
		    return(wordout.element);
		else
		    return(null);
    }
        
    public boolean isEmpty()
    //returns whether the concordance is empty
    {
		return(empty);
    }
		
    public Vector inOrderCopy()
    //list the element of the tree alphabetically in a vector
    {
		Vector treedump;
				
		treedump=new Vector();
		listtreeloop(root,treedump);
		return treedump;
    }
		
    private void listtreeloop(TreeNode t, Vector treedump)
    //recursive function for computing tree element
    {
		if (t!=null)
		    {
			listtreeloop(t.left, treedump);
			treedump.addElement(t.element);
			listtreeloop(t.right,treedump);
		    }
    }
		
    public int getsize()
    //returns the size of the tree
    {
		return size;
    }

    public NumTree sortByNum ()
    //Constructs a NumTree that contains all of the element of tree
    {
		NumTree mynumtree;

		mynumtree=new NumTree(size);
		numtreeloop(root,mynumtree);
		return mynumtree;
    }

    private void numtreeloop(TreeNode t, NumTree mynumtree)
    //recursive inner function that tranverses the tree and adds to the numtree
    {
		if (t!=null)
		    {
			numtreeloop(t.left,mynumtree);
			mynumtree.add(t.element);
			numtreeloop(t.right,mynumtree);
		    }
    }
}
