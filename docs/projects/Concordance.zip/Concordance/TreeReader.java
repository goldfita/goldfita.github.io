interface TreeReader 
//interface for reading into a tree{
    public String readTree();
}
