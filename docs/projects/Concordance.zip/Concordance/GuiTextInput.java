import java.awt.*;
import java.awt.event.*;


/** Just an input box. */
public class GuiTextInput extends Frame//implements popup boxes to get text input, like file names
{
    private Button ok;						//button to exit
	private TextField type;					//place to enter text
    private Label theMessage;				//box label
    private ActionListener actionListener;

    public GuiTextInput(ActionListener al, String msg) 	{
		actionListener = al;				//sets up action listener
		type = new TextField();				//sets up text field
		theMessage = new Label(msg);		//and label
		ok = new Button("Okay :o)");				//creates button
		ok.setName ("Okay :o)");			//and names it

		add(theMessage, "North");			//puts label at top
		add(type, "Center");				//text field in middle
		add(ok, "South");					//and button at the bottom
		pack();								//packs it in
		ok.addActionListener (al);			//and activates button
		
		setTitle ("Input Box");				//names window
		show();								//makes it visible
    }

    public String getText() 	{
		return type.getText();				//returns stuff entered in text field
    }
}
