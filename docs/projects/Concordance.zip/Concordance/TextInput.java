import java.io.*;
import java.util.*;

public class TextInput
//reads the input file and breaks into sentences{
    public final static int PARSE_BY_NEWLINE = 0;
    public final static int PARSE_BY_SENTENCE = 1;
    private Vector sentence;
    private BufferedReader theFile;
    private int breakMethod;

    public TextInput(String f, int brkm) throws FileNotFoundException 
	//the constructor opens the file and sets up the vector to hold sentences	{
		theFile = new BufferedReader(new FileReader(f));
		sentence = new Vector();
		breakMethod = brkm;
    }

    public Vector read()
	//reads the file into a format that can be displayed	{
		String s="", text="";

		try 		{
			if(breakMethod==TextInput.PARSE_BY_NEWLINE)	//reads a line
				while((s=theFile.readLine()) != null)
					sentence.addElement(s);				//sentences it
			else
				while((s=theFile.readLine()) != null)
					text += s+" ";
		}
		catch(IOException ioe) 
		//if a problem occurs in file read...		{ 			ioe.printStackTrace(); 		}
	
		if(breakMethod==PARSE_BY_SENTENCE) 		{
			SentenceTokenizer aSentence = new SentenceTokenizer(text);	//formats by sentences, rather than lines
			while(aSentence.hasMoreTokens())
				sentence.addElement(aSentence.nextToken());
		}
		return sentence;
    }

    public int numSentences()
	//returns number of sentences created	{
		return sentence.size();
    }

    public String getSentence(int n)
	//finds a particular sentence	{
		return (String)sentence.elementAt(n);
    }
}
