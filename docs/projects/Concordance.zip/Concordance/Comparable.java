public interface Comparable //defines the comparable interface so that it may be applied to words{
    public boolean lessThan(Comparable e, int method);
    public int compareTo(Comparable e, int method);
}
