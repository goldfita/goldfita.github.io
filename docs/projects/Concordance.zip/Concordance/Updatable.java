public interface Updatable //interface for updating a comparable{
    public void update(Comparable e, int method);
}
